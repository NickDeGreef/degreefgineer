#include <iostream>
#include <string>
#include <fstream>
#include "CredtCard.h"

#ifndef BANKACCOUNT_H
#define BANKACCOUNT_H

using namespace std;

class BankAccount
{
    private:
    string name;
    
    protected:
    CreditCard:CreditCard; 

    public:


};

#endif
