#include <iostream>
#include <string>
#include <fstream>
#include "utilis.h"

using namespace std; 

int main(){
    cout << "thanks\n";
    return 0; 
}