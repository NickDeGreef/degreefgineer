#include <iostream>
#include <string>
#include <fstream>
#include "BankAccount.h"

#ifndef CREDITCARD_H
#define CREDITCARD_H

using namespace std;

class CreditCard: public BankAccount
{
  private:
    int number[];
    int score;
    int credit; //available credit
    double balance;
    //payment date?
    //transaction history?
    //struct Transaction?
    // Transaction Transactions[]
  public:
    double getBalance();
    double getScore();
    double getAvailableCredit();
};

#endif

/*

git clone     //clones repository from githup
git status    //shows which files have been changes
git add .     //updates files in folder
git commit -m "your message here" //adds comment to commited git
git push .    //sends folder to cloud (all will be sent)
git pull      //

*/
