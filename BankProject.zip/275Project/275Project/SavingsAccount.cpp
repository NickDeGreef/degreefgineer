/*
Savings Account class 
Author: Tylor Franca
Version: 1.0.0
*/


#include "SavingsAccount.h"
#include <string> 
#include <fstream>
#include <iostream>

   /**
      Constructs a Savings account with a $1000 balance.
   */

  // balance not being initialized correctly, needs fix
SavingsAccount::SavingsAccount(){

}


