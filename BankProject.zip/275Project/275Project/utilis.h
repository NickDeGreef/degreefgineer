//header file containing functions 
//****DONT USE 'using namespace std'******

