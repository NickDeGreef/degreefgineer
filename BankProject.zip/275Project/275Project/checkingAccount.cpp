/*
Savings Account class 
Author: Tylor Franca
Version: 1.0.0
*/

#include "checkingAccount.h"
#include "BankAccount.h" 
#include <string> 
#include <fstream>
#include <iostream>


CheckingAccount::CheckingAccount(){
    
}
    



